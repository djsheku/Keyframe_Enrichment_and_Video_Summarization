import { getCurrentTab, getCurrentDomain, getURLWithParameters } from '../common/utils.js';
import { getPuzzleMeUrl, getPuzzleMeIframeCSS } from '../common/df_utils.js';
import { getDomainConfig } from '../common/storage.js';
import * as messenger from '../common/messenger.js';

// initialize popup
addEventListeners();

/**
 * Adds all required event listeners for dragonfly actions.
 */
function addEventListeners() {

  document.addEventListener('DOMContentLoaded', initializePopupOnContentOnLoad);
  document.getElementById('startDragonfly').addEventListener('click', startElementPicker);
  document.getElementById('saveConfig').addEventListener('click', updateCurrentDomainConfig);
  document.getElementById('shareDragonfly').addEventListener('click', shareDragonflyUrl);
  document.getElementById('injectDragonfly').addEventListener('click', injectPuzzleMeIframe);

  document.getElementById('puzzleMeForm').addEventListener('change', updatePuzzleMeUrl);
  document.getElementById('dimensionsForm').addEventListener('change', updatePuzzleMeDimensions);
  document.getElementById('themeSwitch').addEventListener('click', updatePuzzleMeTheme);
  document.getElementById('themeOptionsForm').addEventListener('change', updatePuzzleMeTheme);
  document.getElementById('elementSelector').addEventListener('change', updateElementSelector);
};

/**
 * Populates the popup with the data from the storage.
 * @param {object} domainConfig - the data to populate the popup with.
 */
async function populatePopupConfigWithDomainConfig(domainConfig) {

  try {
    document.getElementById('puzzleType').value = domainConfig.puzzleType || 'demo-crossword';
    document.getElementById('embedType').value = domainConfig.embedType || 'single';
    document.getElementById('widthInput').value = domainConfig.width || 700;
    document.getElementById('heightInput').value = domainConfig.height || 700;

    document.getElementById('elementSelector').value = domainConfig.elementSelector || '';

    if (domainConfig.replaceSwitch) { // checks for presence
      if (domainConfig.replaceSwitch) { // checks for value
        document.querySelector('input[name="replaceOrInsert"][value=true]').checked = true;
      } else {
        document.querySelector('input[name="replaceOrInsert"][value=false]').checked = true;
      }
    } else {
      document.querySelector('input[name="replaceOrInsert"][value=true]').checked = true;
    }

    document.getElementById('themeSwitch').checked = domainConfig.themeSwitch ? domainConfig.themeSwitch.enabled : false;
    document.getElementById('primaryColor').value = domainConfig.themeSwitch ? domainConfig.themeSwitch.primary : '#000000';
    document.getElementById('secondaryColor').value = domainConfig.themeSwitch ? domainConfig.themeSwitch.secondary : '#000000';

    const elementSelector = document.getElementById('elementSelector').value;

    if (elementSelector === '.df-selected') {
      document.getElementById('elementSelectorWarning').innerText = 'Unstable selector. Will not work when shared.';
    } else {
      const numberOfElements = await getNumberOfElements(elementSelector);
      setWarningMessage(numberOfElements);
    }

  } catch (error) {
    sendToLogger('WARN', 'POPUP', 'Trouble populating popup with domain config: ', error);
    toggleButtonState(true);
  }
}

/**
 * Collects values from all the fields and returns them as a json object.
 * @returns {object} the data as a json object
 */
function getPopupConfigForDomain() {

  const puzzleType = document.getElementById('puzzleType').value;
  const embedType = document.getElementById('embedType').value;
  const url = getPuzzleMeUrl(puzzleType, embedType);

  const elementSelector = document.getElementById('elementSelector').value;

  const replaceSwitch = document.querySelector('input[name="replaceOrInsert"]:checked').value === "true" ? true : false;

  const height = document.getElementById('heightInput').value;
  const width = document.getElementById('widthInput').value;

  const themeSwitch = {
    'enabled': document.getElementById('themeSwitch').checked,
    'primary': document.getElementById('primaryColor').value,
    'secondary': document.getElementById('secondaryColor').value
  };

  return {
    'puzzleType': puzzleType,
    'embedType': embedType,
    'url': url,
    'elementSelector': elementSelector,
    'height': height,
    'width': width,
    'replaceSwitch': replaceSwitch,
    'themeSwitch': themeSwitch
  };
}

// handlers
/**
 * Initializes the popup window on content load.
 */
function initializePopupOnContentOnLoad() {

  getCurrentTab().then(async tab => {

    const domain = getCurrentDomain(tab);
    const domainConfig = await getDomainConfig(domain);

    populatePopupConfigWithDomainConfig(domainConfig); // always use populate with storage data
    showOrHideThemeOptions();
  });
}

/**
 * Sets up the element picker and configures the popup window.
 */
function startElementPicker() {

  sendToLogger('INFO', 'POPUP', 'User tried starting element picker');

  getCurrentTab().then(tab => {
    messenger.sendMessageToContentScript(tab.id, {
      event: messenger.REQUESTS.SETUP_ELEMENT_PICKER
    }).then(response => {
      sendToLogger('INFO', 'POPUP', 'Element picker started: ', response);
    }).catch(error => {
      sendToLogger('ERROR', 'POPUP', 'Error starting element picker: ', error);
    });
  });

  window.close();
}

/**
 * Copies the current tab url with dragonfly config parameters to clipboard
 */
async function shareDragonflyUrl() {

  document.getElementById('shareDragonfly').innerText = 'Copied!';

  setTimeout(() => {
    document.getElementById('shareDragonfly').innerText = 'Share URL';
  }, 5000);

  sendToLogger('INFO', 'POPUP', 'User tried sharing Dragonfly URL');

  getCurrentTab().then(async tab => {
    let currentUrl = new URL(tab.url);

    if (currentUrl.searchParams.has('df_edit')) {
      currentUrl.searchParams.delete('df_edit');
    }

    const domain = getCurrentDomain(tab);
    const domainConfig = await getDomainConfig(domain);
    const newUrlParams = {
      'dragonfly': domainConfig
    };
    const newUrl = getURLWithParameters(currentUrl, newUrlParams);

    navigator.clipboard.writeText(newUrl);
  });
}

/**
 * Starts the process of injecting the puzzle me iframe into the page
 */
function injectPuzzleMeIframe() {

  sendToLogger('INFO', 'POPUP', 'User tried injecting PuzzleMe iframe');

  const domainConfig = updateCurrentDomainConfig();

  getCurrentTab().then(tab => {
    messenger.sendMessageToContentScript(tab.id, {
      event: messenger.REQUESTS.INJECT_PUZZLE,
      data: {
        domainConfig: domainConfig
      }
    }).then(response => {
      sendToLogger('INFO', 'POPUP', 'PuzzleMe Iframe injected: ', response);

      messenger.sendMessageToContentScript(tab.id, {
        event: messenger.REQUESTS.UNSET_ELEMENT_PICKER
      });
    }).catch(error => {
      sendToLogger('ERROR', 'POPUP', 'Error injecting PuzzleMe Iframe: ', error);
    });
  });
}

/**
 * Updates the domain config with the values from the popup form
 */
function updateCurrentDomainConfig() {

  const domainConfig = getPopupConfigForDomain();

  document.getElementById('saveConfig').innerText = 'Saved!';
  setTimeout(() => {
    document.getElementById('saveConfig').innerText = 'Save Config';
  }, 5000);

  sendToLogger('INFO', 'POPUP', 'User tried updating domain config: ', domainConfig);

  messenger.sendMessageToBackground({
    event: messenger.REQUESTS.UPDATE_DOMAIN_CONFIG,
    data: {
      domainConfig: domainConfig
    }
  }).then(response => {
    sendToLogger('INFO', 'POPUP', 'Domain config updated: ', response);
  });

  return domainConfig;
}

/**
 * Updates the puzzle me url in the domain config, sends a message to content script to dynamically update the iframe src.
 */
function updatePuzzleMeUrl() {

  const puzzleType = document.getElementById('puzzleType').value;
  const embedType = document.getElementById('embedType').value;
  const url = getPuzzleMeUrl(puzzleType, embedType);

  const domainConfig = {
    'puzzleType': puzzleType,
    'embedType': embedType,
    'url': url
  };

  sendToLogger('INFO', 'POPUP', 'User tried updating url: ', domainConfig);

  messenger.sendMessageToBackground({
    event: messenger.REQUESTS.UPDATE_DOMAIN_CONFIG,
    data: {
      domainConfig: domainConfig
    }
  }).then(response => {
    sendToLogger('INFO', 'POPUP', 'Url updated: ', response);
  });

  updatePuzzleMeIframe('url', domainConfig);
}

/**
 * Updates the puzzle me dimensions in the domain config, sends a message to content script to dynamically update the iframe dimensions.
 */
function updatePuzzleMeDimensions() {

  const height = document.getElementById('heightInput').value;
  const width = document.getElementById('widthInput').value;

  const domainConfig = {
    'height': height,
    'width': width
  };

  sendToLogger('INFO', 'POPUP', 'User tried updating dimensions: ', domainConfig);

  messenger.sendMessageToBackground({
    event: messenger.REQUESTS.UPDATE_DOMAIN_CONFIG,
    data: {
      domainConfig: domainConfig
    }
  }).then(response => {
    sendToLogger('INFO', 'POPUP', 'Dimensions updated: ', response);
  });

  updatePuzzleMeIframe('dimensions', domainConfig);
}

/**
 * Sends a message to the content script to update the puzzle me iframe with the new data.
 * @param {string} updateType - the type of update to be done. either 'url' or 'dimensions'
 * @param {object} updateData - the data to be updated
 */
function updatePuzzleMeIframe(updateType, updateData) {

  const updateTypeEnum = Object.freeze({
    'url': 'url',
    'dimensions': 'dimensions'
  });

  if (updateType === updateTypeEnum.url || updateType === updateTypeEnum.dimensions) {

    if (updateType === updateTypeEnum.url && !updateData.url) {
      sendToLogger('ERROR', 'POPUP', 'Invalid url: ', updateData);
      return;
    }

    if (updateType === updateTypeEnum.dimensions && (!updateData.height || !updateData.width)) {
      sendToLogger('ERROR', 'POPUP', 'Invalid dimensions: ', updateData);
      return;
    }

    getCurrentTab().then(tab => {
      messenger.sendMessageToContentScript(tab.id, {
        event: messenger.REQUESTS.UPDATE_PUZZLEME_IFRAME,
        data: {
          updateType: updateType,
          updateData: updateData
        }
      }).then(response => {
        sendToLogger('INFO', 'POPUP', `Iframe updated with ${updateType}: `, updateData.url || updateData);
      }).catch(error => {
        sendToLogger('ERROR', 'POPUP', `Error updating iframe ${updateType}: `, error);
      });
    });
  } else {
    sendToLogger('ERROR', 'POPUP', 'Invalid update type: ', updateType);
  }
}

/**
 * Applies a theme to the PuzzleMe iframe
 */
function updatePuzzleMeTheme() {

  sendToLogger('INFO', 'POPUP', 'User tried updating theme', null);

  let showTheme = showOrHideThemeOptions();
  const primary = document.getElementById('primaryColor').value;
  const secondary = document.getElementById('secondaryColor').value;
  const themeCSS = primary === secondary ? null : getPuzzleMeIframeCSS(primary, secondary);

  messenger.sendMessageToBackground({
    event: messenger.REQUESTS.UPDATE_PUZZLEME_THEME,
    data: {
      domainConfig: {
        themeSwitch: {
          enabled: showTheme,
          primary: primary,
          secondary: secondary
        }
      },
      css: themeCSS
    }
  }).then(response => {
    sendToLogger('INFO', 'POPUP', 'Theme updated: ', response);
  });
}

/**
* Decides on whether to show theming options or not.
* @returns {boolean} - the value of the theme switch
*/
function showOrHideThemeOptions() {

  let showTheme = document.getElementById("themeSwitch").checked;

  if (showTheme) {
    document.getElementById("themeOptionsForm").style.display = 'flex';
  } else {
    document.getElementById("themeOptionsForm").style.display = 'none';
  }

  return showTheme;
}

/**
 * Updates the element identifier in the domain config
 */
async function updateElementSelector() {

  const elementSelector = document.getElementById('elementSelector').value;

  const numberOfElements = await getNumberOfElements(elementSelector);

  setWarningMessage(numberOfElements);

  if (numberOfElements >= 1) {
    const domainConfig = {
      'elementSelector': elementSelector
    };

    sendToLogger('INFO', 'POPUP', 'User tried updating element identifier: ', domainConfig);

    messenger.sendMessageToBackground({
      event: messenger.REQUESTS.UPDATE_DOMAIN_CONFIG,
      data: {
        domainConfig: domainConfig
      }
    }).then(response => {
      sendToLogger('INFO', 'POPUP', 'Element identifier updated: ', response);
    }).catch(error => {
      sendToLogger('ERROR', 'POPUP', 'Error updating element identifier: ', error);
    });
  }
}

/**
 * Returns the number of elements with the same identifier.
 * @param {string} elementSelector - the element selector
 * @returns {number} the number of elements with the same identifier
 */
async function getNumberOfElements(elementSelector) {

  const domainConfig = {
    'elementSelector': elementSelector
  };
  const tab = await getCurrentTab();
  const response = await messenger.sendMessageToContentScript(tab.id, {
    event: messenger.REQUESTS.CHECK_NUMBER_OF_ELEMENTS,
    data: {
      domainConfig: domainConfig
    }
  });
  const numberOfElements = response.data.numberOfElements;

  return numberOfElements;
}

/**
* @param {number} numberOfElements - the number of elements found with the given selector
*/
function setWarningMessage(numberOfElements) {

  if (numberOfElements !== 1) {
    if (numberOfElements === 0) {
      toggleButtonState(true);
      document.getElementById('elementSelectorWarning').innerText = `Found ${numberOfElements} elements with this selector.`;
      sendToLogger('ERROR', '[POPUP]', `${numberOfElements} elements found with the selector: `, document.getElementById('elementSelector').value);
      return;
    }
    toggleButtonState(false);
    document.getElementById('elementSelectorWarning').innerText = `Found ${numberOfElements} elements with this selector. Selected the first element.`;
    sendToLogger('WARN', '[POPUP]', `${numberOfElements} elements found with the selector: `, document.getElementById('elementSelector').value);
  } else {
    toggleButtonState(false);
    document.getElementById('elementSelectorWarning').innerText = '';
    sendToLogger('INFO', '[POPUP]', `${numberOfElements} element found with the selector`, document.getElementById('elementSelector').value);
  }
}

/**
 * Disable/Enable buttons
 * @param {boolean} disable - true to disable
 */
function toggleButtonState(disable = true) {
  document.getElementById('injectDragonfly').disabled = disable;
  document.getElementById('shareDragonfly').disabled = disable;
  document.getElementById('saveConfig').disabled = disable;

  if (disable) {
    document.getElementById('injectDragonfly').classList.add('disabled');
    document.getElementById('shareDragonfly').classList.add('disabled');
    document.getElementById('saveConfig').classList.add('disabled');
  } else {
    document.getElementById('injectDragonfly').classList.remove('disabled');
    document.getElementById('shareDragonfly').classList.remove('disabled');
    document.getElementById('saveConfig').classList.remove('disabled');
  }
}

/**
 * Sends a message to the background to log the message.
 * @param {string} level 
 * @param {string} location 
 * @param {any} message 
 * @param {any} args 
 */
function sendToLogger(level, location, message, ...args) {

  messenger.sendMessageToBackground({
    event: messenger.REQUESTS.LOG,
    data: {
      level: level,
      location: location,
      message: message,
      args: args
    }
  });
}