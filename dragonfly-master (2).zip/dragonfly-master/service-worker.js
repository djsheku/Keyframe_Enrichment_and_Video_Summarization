import { REQUESTS } from './common/messenger.js';
import { getDomainConfig, updateDomainConfig } from './common/storage.js';
import { getCurrentTab, getCurrentDomain } from './common/utils.js';
import { getPuzzleMeIframeCSS, updatePuzzleMeTheme } from './common/df_utils.js';
import { logger } from './logger/logger.js'; // for this service worker

chrome.runtime.onMessage.addListener(async (request, sender, response) => {

    switch (String(request.event)) {

        case REQUESTS.UPDATE_DOMAIN_CONFIG:
            logger.info('[SERVICE WORKER]', 'Received request:', request.event, request);

            {
                const domainConfig = request.data.domainConfig;

                getCurrentTab().then(tab => {
                    const domain = getCurrentDomain(tab);

                    logger.info('[SERVICE WORKER]', 'Updating domain config:', domain, domainConfig);

                    updateDomainConfig(domain, domainConfig);
                    response({
                        event: REQUESTS.UPDATE_DOMAIN_CONFIG,
                        status: REQUESTS.SUCCESS
                    });
                }).catch(error => {
                    logger.error('[SERVICE WORKER]', 'Error updating domain config:', error);
                    response({
                        event: REQUESTS.UPDATE_DOMAIN_CONFIG,
                        status: REQUESTS.FAIL
                    });
                });
            }
            break;

        case REQUESTS.UPDATE_PUZZLEME_THEME:
            logger.info('[SERVICE WORKER]', 'Received request:', request.event, request);

            {
                const domainConfig = request.data.domainConfig;
                const themeCSS = request.data.css;
                const themeEnabled = domainConfig.themeSwitch.enabled;

                updatePuzzleMeTheme(themeCSS, themeEnabled);
                getCurrentTab().then(tab => {
                    const domain = getCurrentDomain(tab);

                    logger.info('[SERVICE WORKER]', 'Updating domain config:', domain, domainConfig);

                    const numberOfFrames = updateDomainConfig(domain, domainConfig);

                    if (numberOfFrames === 0) {
                        logger.warn('[SERVICE WORKER]', 'No PuzzleMe frames found on the page:', domain);
                    }

                    response({
                        event: REQUESTS.UPDATE_PUZZLEME_THEME,
                        status: REQUESTS.SUCCESS
                    });
                }).catch(error => {
                    logger.error('[SERVICE WORKER]', 'Error updating domain config:', error);
                    response({
                        event: REQUESTS.UPDATE_PUZZLEME_THEME,
                        status: REQUESTS.FAIL
                    });
                });
            }
            break;

        case REQUESTS.UPDATE_PUZZLEME_THEME_ONLOAD: // from content-script
            logger.info('[SERVICE WORKER]', 'Received request:', request.event, request);

            {
                const domain = request.data.domain; // was barred when in mobile view
                const domainConfig = await getDomainConfig(domain);
                const domainConfigTheme = domainConfig.themeSwitch;

                if (!domainConfigTheme.enabled) break;

                const themeCSS = getPuzzleMeIframeCSS(domainConfigTheme.primary, domainConfigTheme.secondary);

                const numberOfFrames = updatePuzzleMeTheme(themeCSS, domainConfigTheme.enabled);

                if (numberOfFrames === 0) {
                    logger.warn('[SERVICE WORKER]', 'No PuzzleMe frames found on the page:', domain);
                }

                response({
                    event: REQUESTS.UPDATE_PUZZLEME_THEME_ONLOAD,
                    status: REQUESTS.SUCCESS
                });
            }
            break;

        case REQUESTS.TOGGLE_MOBILE_VIEW: // from content-script
            logger.info('[SERVICE WORKER]', 'Received request:', request.event, request);

            const runningOnMobile = request.data.runningOnMobile;
            logger.info('[SERVICE WORKER]', 'Toggling mobile view:', runningOnMobile);

            fetch(chrome.runtime.getURL('rules.json')).then(response => response.json()).then(rules => {
                if (runningOnMobile) {
                    // stackoverflow: https://stackoverflow.com/a/73086106
                    chrome.declarativeNetRequest.getDynamicRules(previousRules => {
                        const previousRuleIds = previousRules.map(rule => rule.id);
                        chrome.declarativeNetRequest.updateDynamicRules({
                            removeRuleIds: previousRuleIds,
                            addRules: rules
                        });
                    });
                } else {
                    const modifiedRules = rules.map(rule => ({
                        ...rule,
                        action: {
                            type: "redirect",
                            redirect: {
                                transform: {
                                    queryTransform: {
                                        removeParams: ["runningOnMobile"]
                                    }
                                }
                            }
                        }
                    }));
                    chrome.declarativeNetRequest.updateDynamicRules({
                        addRules: modifiedRules,
                        removeRuleIds: rules.map(rule => rule.id)
                    });
                }
            }).catch(error => {
                logger.error('[SERVICE WORKER]', 'Error toggling mobile view:', error);
            });
            break;

        case REQUESTS.LOG:
            logger.log(request.data.level, request.data.location, request.data.message, request.data.args);
            break;

        default:
            logger.error('[SERVICE WORKER]', 'Received unknown request:', request);
    }
});
