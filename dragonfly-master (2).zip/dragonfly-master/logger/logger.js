class Logger {
    constructor(level) {
        this.levels = {
            ERROR: 0,
            WARN: 1,
            INFO: 2
        };
        this.colors = {
            ERROR: '#f44336',
            WARN: '#ffa726',
            INFO: '#29b6f6'
        }
        this.level = this.levels[level] || this.levels.INFO;
    }

    log(level, location, message, ...args) {
        const timestamp = new Date().toUTCString();
        const colorCode = this.colors[level];
        console.log(`[${timestamp}] %c ${level}`, `color: ${colorCode}`, `[${location}]: ${message}`, ...args);
    }

    info(location, message, ...args) {
        this.log('INFO', location, message, ...args);
    }

    warn(location, message, ...args) {
        this.log('WARN', location, message, ...args);
    }

    error(location, message, ...args) {
        this.log('ERROR', location, message, ...args);
    }
}

export const logger = new Logger();
