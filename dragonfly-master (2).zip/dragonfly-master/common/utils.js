// context handler

/**
 * Returns the current tab.
 * @param {json} query - Query to be used to get the tab. Default: { active: true, currentWindow: true }
 * @returns {chrome.tabs.Tab}
 */
export async function getCurrentTab(query = { active: true, currentWindow: true }) {
  const tabs = await chrome.tabs.query(query);
  return tabs[0];
}

/**
 * Returns the hostname of the given tab.
 * @param {chrome.tabs.Tab} tab - the tab for which to find the domain
 * @returns {string}
 */
export function getCurrentDomain(tab) {
  const url = new URL(tab.url);
  const hostname = url.hostname;
  return hostname;
}

/**
 * Returns the given URL attached with the given parameters.
 * @param {URL} url - the base URL
 * @param {object} queryParameters - the parameter map to be set in the URL
 * @returns {URL}
 */
export function getURLWithParameters(url, queryParameters) {

  /**
 * Returns the base64 conversion of the supplied object
 * @param {json} obj - the json object to be converted
 * @returns {string}
 */
  function encodeObject(obj) {
    // json to base64
    const json = JSON.stringify(obj);
    return btoa(json);
  }

  let newURL = new URL(url);

  for (const [key, value] of Object.entries(queryParameters)) {
    newURL.searchParams.set(key, encodeObject(value));
  }

  return newURL;
}
