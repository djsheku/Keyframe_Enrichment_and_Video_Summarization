import { getCurrentTab } from './utils.js';
/**
 * Generates and returns the puzzle me link using the puzzleType and embedType.
 * @param {string} puzzleType - the type of puzzle to be generated
 * @param {string} embedType - the type of embedding to be done
 * @param {number} idx - the index of the puzzle in the puzzle picker
 * @returns {string}
 */
export function getPuzzleMeUrl(puzzleType, embedType, idx = 1) {
  let puzzleMeUrl = `https://amuselabs.com/pmm/date-picker`;
  puzzleMeUrl = new URL(puzzleMeUrl);
  puzzleMeUrl.searchParams.set('set', `${puzzleType}`);

  if (embedType === 'single') {
    puzzleMeUrl.searchParams.set('idx', idx);
    // overrides
    if (puzzleType == 'demo-rows-garden') {
      puzzleMeUrl = new URL ("https://puzzleme.amuselabs.com/pmm/crossword?&set=demo-variety&id=45d30937");
    } else if (puzzleType == 'demo-decipher') { 
      puzzleMeUrl = new URL ('https://cdn2.amuselabs.com/pmm/crossword?id=f4585f1a&set=morningbrew-morningbrew-decipher&test=1'); // test=1 to avoid causing Mbrew loads
    } else if (puzzleType == 'demo-spiral') {
      puzzleMeUrl = new URL ('https://puzzleme.amuselabs.com/pmm/crossword?&set=demo-demo-mini-spiral&id=abcdefgh'); 
    } else if (puzzleType == 'demo-marching-bands') {
      puzzleMeUrl = new URL ('https://puzzleme.amuselabs.com/pmm/crossword?&set=demo-variety&id=accea7e5');
    }
  }


  puzzleMeUrl.searchParams.set('embed', '1');

  return puzzleMeUrl;
}

/**
 * Returns an array of the frame IDs of the PuzzleMe frames in the given tab.
 * @param {chrome.tabs.Tab} tab - the tab to be checked for the presence of PuzzleMe frames
 * @returns {Array}
 */
export async function getPuzzleMeFramesID(tab) {
  let frames = await chrome.webNavigation.getAllFrames({ tabId: tab.id }); // returns a promise although placing await makes it say it does not affect

  let puzzleMeFramesIDs = [];

  frames.forEach(frame => {
    const frameUrl = new URL(frame.url);
    const hostname = frameUrl.hostname;

    if (hostname === 'amuselabs.com' && frame.frameType !== 'outermost_frame') {
      puzzleMeFramesIDs.push(frame.frameId);
    }
  });

  return puzzleMeFramesIDs;
}

/**
 * Updates the puzzle me iframe theme.
 * @param {string} themeCSS - the CSS to be applied
 * @param {boolean} applyTheme - whether to apply or unapply
 * @returns {Number} number of frames
 */
export function updatePuzzleMeTheme(themeCSS = null, applyTheme = true) {
  /**
   * Jams the given themeCSS.
   * @param {string} themeCSS - the CSS to jam
   */
  function injectPuzzleMeTheme(themeCSS) {
    let customStyle = document.getElementById('customized-style-element');

    if (!customStyle) {
      customStyle = document.createElement('style');
      customStyle.id = 'customized-style-element';
      document.head.appendChild(customStyle);
    }

    customStyle.innerText = themeCSS;
  }

  /**
   * Removes the theme.
   */
  function removePuzzleMeTheme() {
    let customStyle = document.getElementById('customized-style-element');

    if (!customStyle) {
      return;
    }
    customStyle.innerText = '';
  }

  /**
   * Runs scripts in the PuzzleMe iframes
   * @param {CallableFunction} functionToApply 
   * @param {string} themeCSS 
   */
  function applyOrUnapplyTheme(functionToApply, themeCSS = null) {
    let frameIds = [];
    getCurrentTab().then(async tab => {
      frameIds = await getPuzzleMeFramesID(tab);

      if (frameIds.length === 0) {
        console.log("No PuzzleMe frames found!");
      } else {
        chrome.scripting.executeScript({
          target: {
            tabId: tab.id,
            frameIds: frameIds
          },
          function: functionToApply,
          args: [themeCSS]
        });
      }
    });
    return frameIds.length;
  }

  let numberOfFrames = 0;
  if (applyTheme) {
    numberOfFrames = applyOrUnapplyTheme(injectPuzzleMeTheme, themeCSS);
  } else {
    numberOfFrames = applyOrUnapplyTheme(removePuzzleMeTheme, null);
  }
  return numberOfFrames;
}

/**
 * Generates and returns a CSS for jamming the PuzzleMe iframe
 * @param {hexString} primary - the primary color
 * @param {hexString} secondary - the secondary color
 * @returns {string}
 */
export function getPuzzleMeIframeCSS(primary, secondary) {

  // taken from PMM
  function getFGColor(hexString) {

    // Source: https://stackoverflow.com/questions/5623838/rgb-to-hex-and-hex-to-rgb
    function hexToRgb(hexString) {
      var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hexString);
      return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
      } : null;
    }

    // Function taken from : https://stackoverflow.com/questions/11867545/change-text-color-based-on-brightness-of-the-covered-background-area
    // More info here : http://www.nbdtech.com/Blog/archive/2008/04/27/Calculating-the-Perceived-Brightness-of-a-Color.aspx
    let color = hexToRgb(hexString);
    let o = Math.round(((color.r * 299) + (color.g * 587) + (color.b * 114)) / 1000);

    return (o > 125) ? '#000000' : '#ffffff';
  }

  const fg1 = getFGColor(primary);
  const fg2 = getFGColor(secondary);

  return `
                              /*!
     * Version: 2.2.7
     * Copyright (c) 2013-2023 Amuse Labs Pvt Ltd
     */
    /*!
     * Copyright (c) 2013-2023 Amuse Labs Pvt Ltd
     */
    /*!
     * Copyright (c) 2013-2024 Amuse Labs Pvt Ltd
     */
    /*!
     * Copyright (c) 2013-2024 Amuse Labs Pvt Ltd
     */
    /*!
     * Copyright (c) 2013-2023 Amuse Labs Pvt Ltd
     */
    /*!
     * Copyright (c) 2013-2024 Amuse Labs Pvt Ltd
     */
    .pm-xword-body {
      font-family: Helvetica;
    }
    .pm-xword-body .grid-area .hilited-box-with-focus {
      background-color: ${primary};
      color: ${fg1};
    }
    .pm-xword-body .grid-area .hilited-box-with-focus .cluenum-in-box {
      color: ${fg1};
    }
    .pm-xword-body .grid-area .hilited-box-with-focus .box-with-background-shape {
      border-color: #000000;
    }
    .pm-xword-body .grid-area .hilited-box {
      background-color: ${secondary};
      color: ${fg2};
    }
    .pm-xword-body .grid-area .hilited-box .cluenum-in-box {
      color: ${fg2};
    }
    .pm-xword-body .grid-area .hilited-box .box-with-background-shape {
      border-color: #000000;
    }
    .pm-xword-body .grid-area .box.box-left-edge, .pm-xword-body .grid-area .box.box-right-edge, .pm-xword-body .grid-area .box.box-top-edge, .pm-xword-body .grid-area .box.box-bottom-edge {
      border-color: rgba(0, 0, 0, 0.4);
      border-width: 1px;
    }
    .pm-xword-body .grid-area .empty {
      background-color: #000000;
    }
    .pm-xword-body .grid-area .stop {
      background-color: rgba(0, 0, 0, 0.8);
    }
    .pm-xword-body .grid-area .box {
      font-weight: 400;
      font-family: Helvetica;
    }
    .pm-xword-body .grid-area .cluenum-in-box {
      font-weight: 400;
      font-family: Helvetica;
    }
    .pm-xword-body .clues-area .hilited-clue {
      background-color: ${secondary};
    }
    .pm-xword-body .clues-area .clueDiv.crossing-clue {
      border-left-color: ${primary};
    }
    .pm-xword-body .clues-area .hilited-clue, .pm-xword-body .clues-area .hilited-clue.done-clue {
      color: ${fg2};
    }
    .pm-xword-body .clue-bar {
      background-color: ${secondary};
      color: ${fg2};
    }
    .pm-xword-body .clue-bar .clue-bar-text .separator {
      border-color: #000000;
    }
    .pm-xword-body .clue-bar .clue-bar-text::selection {
      background-color: ${primary};
      color: ${fg1};
    }
    .pm-xword-body .clue-bar .CLUE-DIRECTION::selection {
      background-color: ${primary};
      color: ${fg1};
    }
    .pm-xword-body .bottom-clue-bar .clue-nav-arrow {
      fill: #000000;
    }
    .pm-xword-body .keyboard .key {
      font-family: Helvetica;
    }
    
    .pm-xword-body .player-modal .modal-title, .pm-xword-body .player-modal .modal-body-title {
      font-family: Helvetica;
    }
    .pm-xword-body .btn {
      background-color: #BBBBBB;
      color: #000;
    }
    .pm-xword-body .btn:hover, .pm-xword-body .btn:focus, .pm-xword-body .btn:active {
      background-color: #E9E9E9;
      color: #000;
    }
    .pm-xword-body .btn-default {
      background-color: ${primary};
      color: ${fg1};
    }
    .pm-xword-body .btn-default:hover, .pm-xword-body .btn-default:focus, .pm-xword-body .btn-default:active {
      background-color: ${secondary};
      color: ${fg2};
    }
    .pm-xword-body .slider-on-bg {
      fill: ${primary};
    }
    
    .pm-xword-body .grid-area .box.player-1-hilited-box-with-focus, .pm-xword-body .grid-area .box.player-1-hilited-box-with-focus.prerevealed-box.letter {
      background-color: #AFD092;
    }
    .pm-xword-body .grid-area .box.hilited-box-with-focus.player-1-hilited-box-with-focus {
      background: repeating-linear-gradient(45deg, ${primary}, ${primary} 10px, #AFD092 10px, #AFD092 20px);
    }
    .pm-xword-body .grid-area .box.player-2-hilited-box-with-focus, .pm-xword-body .grid-area .box.player-2-hilited-box-with-focus.prerevealed-box.letter {
      background-color: #FACD90;
    }
    .pm-xword-body .grid-area .box.hilited-box-with-focus.player-2-hilited-box-with-focus {
      background: repeating-linear-gradient(45deg, ${primary}, ${primary} 10px, #FACD90 10px, #FACD90 20px);
    }
    .pm-xword-body .grid-area .box.player-3-hilited-box-with-focus, .pm-xword-body .grid-area .box.player-3-hilited-box-with-focus.prerevealed-box.letter {
      background-color: #FCD2DC;
    }
    .pm-xword-body .grid-area .box.hilited-box-with-focus.player-3-hilited-box-with-focus {
      background: repeating-linear-gradient(45deg, ${primary}, ${primary} 10px, #FCD2DC 10px, #FCD2DC 20px);
    }
    .pm-xword-body .grid-area .box.player-1-hilited-box:not(.player-1-hilited-box-with-focus) {
      background-color: #DFECD3;
    }
    .pm-xword-body .grid-area .box.hilited-box.player-1-hilited-box:not(.player-1-hilited-box-with-focus) {
      background: repeating-linear-gradient(45deg, ${secondary}, ${secondary} 10px, #DFECD3 10px, #DFECD3 20px);
    }
    .pm-xword-body .grid-area .box.hilited-box.player-1-hilited-box-with-focus {
      background: repeating-linear-gradient(45deg, ${secondary}, ${secondary} 10px, #AFD092 10px, #AFD092 20px);
    }
    .pm-xword-body .grid-area .box.hilited-box-with-focus.player-1-hilited-box:not(.player-1-hilited-box-with-focus) {
      background: repeating-linear-gradient(45deg, ${primary}, ${primary} 10px, #DFECD3 10px, #DFECD3 20px);
    }
    .pm-xword-body .grid-area .box.player-2-hilited-box:not(.player-2-hilited-box-with-focus) {
      background-color: #F4E5D1;
    }
    .pm-xword-body .grid-area .box.hilited-box.player-2-hilited-box:not(.player-2-hilited-box-with-focus) {
      background: repeating-linear-gradient(45deg, ${secondary}, ${secondary} 10px, #F4E5D1 10px, #F4E5D1 20px);
    }
    .pm-xword-body .grid-area .box.hilited-box.player-2-hilited-box-with-focus {
      background: repeating-linear-gradient(45deg, ${secondary}, ${secondary} 10px, #FACD90 10px, #FACD90 20px);
    }
    .pm-xword-body .grid-area .box.hilited-box-with-focus.player-2-hilited-box:not(.player-2-hilited-box-with-focus) {
      background: repeating-linear-gradient(45deg, ${primary}, ${primary} 10px, #F4E5D1 10px, #F4E5D1 20px);
    }
    .pm-xword-body .grid-area .box.player-3-hilited-box:not(.player-3-hilited-box-with-focus) {
      background-color: #FDE8ED;
    }
    .pm-xword-body .grid-area .box.hilited-box.player-3-hilited-box:not(.player-3-hilited-box-with-focus) {
      background: repeating-linear-gradient(45deg, ${secondary}, ${secondary} 10px, #FDE8ED 10px, #FDE8ED 20px);
    }
    .pm-xword-body .grid-area .box.hilited-box.player-3-hilited-box-with-focus {
      background: repeating-linear-gradient(45deg, ${secondary}, ${secondary} 10px, #FCD2DC 10px, #FCD2DC 20px);
    }
    .pm-xword-body .grid-area .box.hilited-box-with-focus.player-3-hilited-box:not(.player-3-hilited-box-with-focus) {
      background: repeating-linear-gradient(45deg, ${primary}, ${primary} 10px, #FDE8ED 10px, #FDE8ED 20px);
    }
    
    #sp-chat-icon .sp-chat-svg-circle {
      fill: ${primary};
    }
    #sp-chat-icon .sp-chat-svg-line {
      fill: #000000;
    }
    
    .social-play-chat .chat-header {
      background-color: ${primary};
    }
    .social-play-chat .chat-header .title {
      color: #000000;
    }
    .social-play-chat .chat-header .close-btn {
      fill: #000000;
    }
    .social-play-chat .messages li.self {
      background-color: ${secondary};
    }
    .social-play-chat .messages li.other.player-1 {
      background-color: #DFECD3;
    }
    .social-play-chat .messages li.other.player-2 {
      background-color: #F4E5D1;
    }
    .social-play-chat .messages li.other.player-3 {
      background-color: #FDE8ED;
    }
    
    .pm-xword-body .clues-area .hilited-clue.wrong-answer-clue {
      color: #000000 !important;
    }
        `
}
