/**
 * Updates the chrome local storage with the domain configuration.
 * @param {String} domain - the domain to update the configuration for.
 * @param {object} domainConfig - the configuration to update the existing domain config with. Will initialize an empty object if the domain does not exist.
 */
export async function updateDomainConfig(domain, domainConfig={}) {
    let currentDomainConfig = await getDomainConfig(domain) || {};
    currentDomainConfig = {...currentDomainConfig, ...domainConfig};
    chrome.storage.sync.set({
        [domain]: currentDomainConfig
    });
}

/**
 * Returns the domain configuration for the given domain. If no domain is provided, returns all domain configurations.
 * @param {String} domain - the domain to get the configuration for. Defaults to null. 
 * @returns {Promise} a promise that resolves with the domain configuration.
 */
export async function getDomainConfig(domain=null) {
    const domainConfig = await chrome.storage.sync.get(domain);
    return domainConfig[domain];
}
