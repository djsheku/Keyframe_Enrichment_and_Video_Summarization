// wrapper around runtime.sendMessage with message enums

export const REQUESTS = Object.freeze({
    CHECK_NUMBER_OF_ELEMENTS: 'checkNumberOfElements', // popup -> content
    SETUP_ELEMENT_PICKER: 'setupElementPicker', // popup -> content
    UNSET_ELEMENT_PICKER: 'unsetElementPicker', // popup -> content
    UPDATE_DOMAIN_CONFIG: 'updateDomainConfig', // popup -> background, content -> background
    INJECT_PUZZLE: 'injectPuzzle', // popup -> content
    UPDATE_PUZZLEME_IFRAME: 'updatePuzzleMeIframe', // popup -> content
    UPDATE_PUZZLEME_THEME: 'updatePuzzleMeTheme', // popup -> background
    UPDATE_PUZZLEME_THEME_ONLOAD: 'updatePuzzleMeThemeOnload',
    REMOVE_PUZZLEME_THEME: 'removePuzzleMeTheme', // popup -> background
    TOGGLE_MOBILE_VIEW: 'viewOnMobile',
    SUCCESS: 'success',
    FAIL: 'fail',
    LOG: 'log'
});

/**
 * Sends a message to the service worker and returns a promise. Wrapper around `chrome.runtime.sendMessage`.
 * @param {object} message - message to send to the service worker.
 * @returns {Promise<any>}
 */
export async function sendMessageToBackground(message) {
    return new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(message, response => {
            if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
            } else {
                resolve(response);
            }
        });
    });
}

/**
 * Sends a message to the content scripts and returns a promise. Wrapper around `chrome.tabs.sendMessage`.
 * @param {chrome.tabs.tabId} tabId 
 * @param {object} message - message to send to the content scripts.
 * @returns {Promise<any>}
 */
export async function sendMessageToContentScript(tabId, message) {
    return new Promise((resolve, reject) => {
        chrome.tabs.sendMessage(tabId, message, response => {
            if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
            } else {
                resolve(response);
            }
        });
    });
}
