# Dragonfly v3.0.0

## Installing the Extension

1) Go to extensions (or manage extensions)
2) Turn on Developer Mode
3) Click on 'Load Unpacked'
4) Select the folder containing the extension
5) You now have the extension loaded; you may pin it to the extension bar (easier access)

## Using the Extension

### Vanilla Usage

1) Click on the extension icon in the toolbar, it will present a form.
2) Click on `Pick Element` to start with the element selection process. The popup will close after you click on it.
3) You are now on the element picker phase. As you hover on the page, different elements will be highlighted.
4) You may choose any of the highlighted elements to replace or insert after, once selected the hightlighted element highlight color will change.
5) Click on the extension icon again. You will see the form again. Some fields may have been updated.
6) You also have the ability to provide and `Element Selector`. In case, the provided element selector is not present, or there are multiple such selectors, you will get to see an error in the popup itself.
7) The radio buttons `Replace` and `Insert` represent the injection strategy. `Replace` replaces the selected element. `Insert` inserts after the selected element.
8) Choose the puzzle kind under `Puzzle Type` dropdown. The dropdown contains all the different kind of puzzles available on the PuzzleMe platform developed by AmuseLabs. Default is a Crossword.
9) Choose the embed type under `Embed Type` dropdown. There are two options:
   1) Single Puzzle - picks the first puzzle of the puzzle picker. (Default)
   2) Puzzle Picker - gets the puzzle picker iframe.
10) In case, you want to select another element, simply select another element. You can select another element as long as the element picker is active.
11) The `Height` and `Width` options are optional. The default dimensions are `700px X 700px`. In case not provided, `Dragonfly` will auto infer the dimensions from the selected element.
12) You may also specify the `Primary` and `Secondary` colors for the PuzzleMe iframe. To enable theme check the `Theme` checkbox.
13) You may click on `Go` to then inject the puzzle.
14) You may also click on `Save Config` button to save the config in the local storage, and exit element picker. However, each change in the form is already updated.
15) You can then copy and share the `Dragonfly` URL by clicking on the `Share URL` button.
16) Once you have the puzzle injected, you can change the puzzle type and embed type using the `Puzzle Type`, and `Embed Type` dropdowns. You can even change the dimensions of the puzzle using the `Height` and `Width` fields.

### Shareable URL

1) In case you have an URL (this URL contains the `dragonfly` param) you would like to test, please have the extension installed.
2) Please navigate to the URL.
3) The changes you made previously will reflect on the page.

<p style="color: red; font-weight: bold;">Note: this might fail on sites which have lazy-loading or sites which load slowly.</p>

## Note

1) There may be instances when the same `Element Selector` may correspond to some different element on page reload, or opening the same page in a new tab
2) There are some elements that cannot be replaced, or even selected, one of them is the 'Lottie-Player'.

## Storage formats

```json
{
    domain1: {
        'url': url,
        'height': height,
        'width': width,
        'elementSelector': elementIdentifier,
        'replaceSwitch': replaceSwitch,
        'themeSwitch': {
            enabled: boolean,
            primary: hex,
            secondary: hex
        }
    }, 
    domain2: {
        'url': url,
        'height': height,
        'width': width,
        'elementIdentifier': elementIdentifier, 
        'replaceSwitch': replaceSwitch,
        'themeSwitch': {
            enabled: boolean,
            primary: hex,
            secondary: hex
        }
    },
    .
    .
    .
}
```

## Message Formats

```json
{
    event: request,
    data: object
}
```
