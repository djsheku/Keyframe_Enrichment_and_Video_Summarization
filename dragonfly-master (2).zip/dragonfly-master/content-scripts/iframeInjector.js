/**
 * Replaces or inserts after the selected element with the given iframe surrounded by a div container.
 * @param {String} selectedElement - the selected element to be replaced or inserted after
 * @param {HTMLIFrameElement} iframe - the iframe to inject.
 * @param {Number} height - the height of the iframe.
 * @param {Number} width - the width of the iframe.
 * @param {boolean} replace - whether to replace the selected element or insert after it. Default: `false`
 * @param {String} iframeContainerClass - the class name of the iframe container. Default: `responsive-iframe-container`
 */
function replaceOrInsertAfterSelectedElement(selectedElement, iframe, height, width, replace = false, iframeContainerClass = 'responsive-iframe-container') {

    /**
     * Sets the height and width of the puzzle me iframe div container
     * @param {number} height - the height of the puzzle me iframe.
     * @param {number} width - the width of the puzzle me iframe.
     * @param {string} classes - the classes of the puzzle me iframe div container.
     * @param {HTMLElement} selectedElement - the element to get the width and height from.
     * @returns {HTMLElement} the div container for the puzzle me iframe.
     */
    function getIframeContainer(height, width, classes, selectedElement) {
        let iframeContainer = document.createElement('div');

        let w = width ? width : selectedElement.offsetWidth < 700 ? 700 : selectedElement.offsetWidth;
        let h = height ? height : selectedElement.offsetHeight < 700 ? w : selectedElement.offsetHeight;

        height = h;
        width = w;

        h = h + 'px';
        w = w + 'px';

        iframeContainer.style.width = w;
        iframeContainer.style.height = h;

        iframeContainer.classList.add(classes);

        // requestToUpdateDomainConfig({ height: height, width: width });

        return iframeContainer;
    }

    try {
        let iframeContainer = getIframeContainer(height, width, iframeContainerClass, selectedElement);
        iframeContainer.innerHTML = iframe.outerHTML;

        if (replace) {
            selectedElement.innerHTML = iframeContainer.outerHTML;
            selectedElement.style.padding = 0;
        } else {
            selectedElement.insertAdjacentHTML('afterend', iframeContainer.outerHTML);
        }
    } catch (error) {
        sendToLogger('ERROR', '[CONTENT-SCRIPT] {iframeInjector.js}', 'Error replacing or inserting after selected element: ', error);
    }
}
