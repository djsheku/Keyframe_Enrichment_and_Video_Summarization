/**
 * Replaces the selected element with the given puzzle or inserts just after it. The iframe is surrounded by a div container.
 * @param {URL} url - the URL of puzzle-me puzzle
 * @param {number} height - the height of the puzzle div container
 * @param {number} width - the width of the puzzle div container    
 * @param {string} selectedElement - the element to replace or insert after
 * @param {boolean} replace - whether to replace the element or insert after it. Default: `false`.
 * @param {string} iframeClass - the class of the inserted iframe. Default: `puzzle-me-iframe`.
 */
function injectPuzzle(url, height, width, selectedElement, replace = false, iframeClass = 'puzzle-me-iframe') {

    const id = getNumberOfPuzzleMeIframes();
    const puzzleMeIframe = getPuzzleMeIframe(url, iframeClass, `puzzle-me-iframe-${id}`);

    replaceOrInsertAfterSelectedElement(selectedElement, puzzleMeIframe, height, width, replace);
}

/**
 * Sets up the element picker and injects puzzle if dragonfly parameter is found in the url.
 */
function injectPuzzleOnLoad() {

    const url = new URL(window.location.href);
    const params = new URLSearchParams(url.search);
    const isDragonflyPresent = params.has('dragonfly');

    if (isDragonflyPresent) {
        sendToLogger('INFO', '[CONTENT-SCRIPT] {puzzleInjector.js}', 'Dragonfly parameter found in URL');
        addPuzzleMeEventListeners();
        setupElementPicker(); // from `elementPicker.js`
        const encodedDomainConfig = params.get('dragonfly');

        /**
         * Returns the json conversion of the supplied base64 string
         * @param {string} str - the base64 string to be converted to json
         * @returns {json} - the json object
         */
        function decodeString(str) {
            // base64 to json
            const json = atob(str);
            return JSON.parse(json);
        }

        if (encodedDomainConfig && url.hostname !== 'extensions') {
            const domainConfig = decodeString(encodedDomainConfig);

            requestToUpdateDomainConfig(domainConfig);

            const elementSelector = domainConfig.elementSelector;
            const selectedElement = getElementsBySelector(elementSelector)[0];

            injectPuzzle(domainConfig.url, domainConfig.height, domainConfig.width, selectedElement, domainConfig.replaceSwitch);
            smoothScrollToLatestPuzzleMeIframe();
        }
        unsetElementPicker(); // from `elementPicker.js
    } else {
        sendToLogger('INFO', '[CONTENT-SCRIPT] {puzzleInjector.js}', 'Dragonfly parameter not found in URL');
    }
}

/**
 * Returns the number of PuzzleMe iframes on the page.
 * @returns {number} the number of PuzzleMe iframes
 */
function getNumberOfPuzzleMeIframes() {
    return document.getElementsByClassName('puzzle-me-iframe').length;
}

/**
 * Returns the puzzle me iframe.
 * @param {string} url - the URL of the puzzle me iframe.
 * @param {string} classes - the classes to be added to the puzzle me iframe.
 * @param {string} id - the id of the puzzle me iframe.
 * @returns {HTMLElement} the puzzle me iframe.
 */
function getPuzzleMeIframe(url, classes, id) {

    const iframe = document.createElement('iframe');
    iframe.src = url;
    iframe.classList.add(classes);
    iframe.id = id;

    return iframe;
}

/**
 * Updates the PuzzleMe iframe.
 * @param {string} updateType - the type of update to be done
 * @param {Object} updateData - the data to be updated
 */
function updatePuzzleMeIframe(updateType, updateData) {

    try {
        const latestId = smoothScrollToLatestPuzzleMeIframe();
        let iframe = document.getElementById(`puzzle-me-iframe-${latestId}`);

        if (updateType === 'url') {
            iframe.src = updateData.url;
        } else if (updateType === 'dimensions') {
            iframe.parentElement.style.height = `${updateData.height}px`;
            iframe.parentElement.style.width = `${updateData.width}px`;
        }
    } catch (error) {
        sendToLogger('ERROR', '[CONTENT-SCRIPT] {puzzleInjector.js}', 'Could not find a PuzzleMe Iframe: ', error);
    }
}

/**
 * Smooth scrolls to the latest inserted PuzzleMe iframe on the page and returns the latest id number.
 * @returns {number} the latest id number
 */
function smoothScrollToLatestPuzzleMeIframe() {

    const idNumber = getNumberOfPuzzleMeIframes();
    let returnId = idNumber;

    try {
        document.getElementById(`puzzle-me-iframe-${idNumber - 1}`).scrollIntoView({
            behavior: 'smooth'
        });
        returnId = idNumber - 1;
    } catch (error) {
        try {
            document.getElementById(`puzzle-me-iframe-${idNumber}`).scrollIntoView({
                behavior: 'smooth'
            });
        } catch (error) {
            sendToLogger('ERROR', '[CONTENT-SCRIPT] {puzzleInjector.js}', 'Could not smooth scroll to latest PuzzleMe iframe as no iframes found:', error);
        }
    }

    return returnId;
}

/**
 * Adds event listeners for the PuzzleMe platform.
 */
function addPuzzleMeEventListeners() {

    window.addEventListener('message', lookForPuzzleLoaded);
    window.addEventListener('resize', viewOnMobile);
}

/**
 * Removes event listeners for the PuzzleMe platform
 */
function removePuzzleMeEventListeners() {

    window.removeEventListener('message', lookForPuzzleLoaded);
}

/**
 * Checks for `puzzleLoaded` message from the PuzzleMe iframe and sends a message to background to theme.
 */
function lookForPuzzleLoaded(event) {
    try {
        const messageEventData = JSON.parse(event.data);
        if (messageEventData.progress && messageEventData.progress === 'puzzleLoaded') {
            const domain = window.location.hostname;
            chrome.runtime.sendMessage({
                event: REQUESTS.UPDATE_PUZZLEME_THEME_ONLOAD,
                data: {
                    domain: domain
                }
            });
        }
    } catch (error) {
        sendToLogger('ERROR', '[CONTENT-SCRIPT] {puzzleInjector.js}', 'Could not parse message event data:', error);
    }
}

/**
 * Checks if the user is on mobile, and sends a message to background to update puzzle.
 */
function viewOnMobile() {

    const isMobile = window.matchMedia("(max-width: 768px)").matches;

    let puzzleMeIframes = document.querySelectorAll('.puzzle-me-iframe');

    if (isMobile) {
        sendToLogger('INFO', '[CONTENT-SCRIPT] {puzzleInjector.js}', 'User is on mobile');

        puzzleMeIframes.forEach(iframe => {
            let url = new URL(iframe.src);
            url.searchParams.set('runningOnMobile', 1);

            iframe.src = url;
        });
    } else {
        puzzleMeIframes.forEach(iframe => {
            let url = new URL(iframe.src);
            url.searchParams.delete('runningOnMobile');

            iframe.src = url;
        });
    }
    smoothScrollToLatestPuzzleMeIframe();

    chrome.runtime.sendMessage({
        event: REQUESTS.VIEW_ON_MOBILE,
        data: {
            runningOnMobile: isMobile
        }
    });
}
