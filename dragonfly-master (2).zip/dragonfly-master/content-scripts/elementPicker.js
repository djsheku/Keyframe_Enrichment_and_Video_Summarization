/**
 * Sets up the element picker.
 */
function setupElementPicker() {

    addElementPickerEventListeners();
}

function unsetElementPicker() {

    try {
        document.getElementsByClassName(selectedClass)[0].classList.remove(selectedClass);
    } catch {
        sendToLogger('INFO', '[CONTENT-SCRIPT] {elementPicker.js}', 'No selected element found!');
    }

    removeElementPickerEventListeners();
}

/**
 *  Adds the required event listeners for ElementPicker to the document
 * 1) A click event listener to handle the click event
 * 2) A mouseover event listener to handle the mouseover event
 * 3) A mouseout event listener to handle the mouseout event 
 */
function addElementPickerEventListeners() {
    document.addEventListener('click', document.clickFn = () => {
        elementSelectedHandler();
    }, true);
    document.addEventListener('mouseover', document.overFn = event => {
        mouseOverHandler(event);
    }, true);
    document.addEventListener('mouseout', document.outFn = event => {
        mouseOutHandler(event);
    }, true);
}

/**
 * Removes the event listeners added by the ElementPicker
 */
function removeElementPickerEventListeners() {
    document.removeEventListener('click', document.clickFn, true);
    document.removeEventListener('mouseover', document.overFn, true);
    document.removeEventListener('mouseout', document.outFn, true);
}

// handler functions
/**
 * Toggles the element picker on and off. Sends a message to background to update.
 */
function elementSelectedHandler() {

    function getLeastOcurringClass(classList) {
        let minOccur = Number.MAX_SAFE_INTEGER;
        let minClass = '';

        classList.forEach(className => {
            let numberOfOccurences = document.getElementsByClassName(className).length;
            if (numberOfOccurences < minOccur && className !== selectedClass && className !== identifierClass) {
                minOccur = numberOfOccurences;
                minClass = className;
            }
        });

        if (minClass === '') {
            return selectedClass;
        }

        return minClass;
    }

    try {
        document.getElementsByClassName(selectedClass)[0].classList.remove(selectedClass);
    } catch {
        sendToLogger('INFO', '[CONTENT-SCRIPT] {elementPicker.js}', 'First element selected!');
    }
    const selectedElement = document.getElementsByClassName(identifierClass)[0];
    selectedElement.classList.toggle(selectedClass);

    const id = selectedElement.id ? (selectedElement.id.startsWith('#') ? selectedElement.id : `#${selectedElement.id}`) : '';
    const className = getLeastOcurringClass(selectedElement.classList);
    const elementSelector = id !== '' ? id : `.${className}`;

    requestToUpdateDomainConfig({ elementSelector: elementSelector });
}

/**
 * Handles the mouseover event. Adds a class to the element being hovered on.
 * @param {Event} event - the mouseover event.
 */
function mouseOverHandler(event) {
    let hoverOnElement = event.target;

    if (eligibleTags.includes(hoverOnElement.nodeName.toLowerCase())) {
        hoverOnElement.classList.add(identifierClass);
    } else if (eligibleTags.includes(hoverOnElement.parentNode.nodeName.toLowerCase())) {
        hoverOnElement.parentNode.classList.add(identifierClass);
    }
}

/**
 * Handles the mouseout event. Removes the class from the element being hovered on.
 * @param {Event} event - the mouseout event.
 */
function mouseOutHandler(event) {
    let hoverOutElement = event.target;

    if (eligibleTags.includes(hoverOutElement.nodeName.toLowerCase())) {
        hoverOutElement.classList.remove(identifierClass);
    } else if (eligibleTags.includes(hoverOutElement.parentNode.nodeName.toLowerCase())) {
        hoverOutElement.parentNode.classList.remove(identifierClass);
    }
}
