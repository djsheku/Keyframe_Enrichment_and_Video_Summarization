// should be able to respond to all messages sent to content scripts
// centralized message handler for all content scripts

document.addEventListener('DOMContentLoaded', () => {
    injectPuzzleOnLoad(); // from `puzzleInjector.js`
});

chrome.runtime.onMessage.addListener((request, sender, response) => {

    switch (String((request.event))) {

        case REQUESTS.SETUP_ELEMENT_PICKER:
            sendToLogger('INFO', '[CONTENT-SCRIPT] {messageHandler.js}', 'Setting up element picker');
            {
                setupElementPicker(); // from `elementPicker.js`
                response({
                    event: REQUESTS.SETUP_ELEMENT_PICKER,
                    data: {
                        status: REQUESTS.SUCCESS
                    }
                });
            }
            break;

        case REQUESTS.UNSET_ELEMENT_PICKER:
            sendToLogger('INFO', '[CONTENT-SCRIPT] {messageHandler.js}', 'Unsetting element picker');
            {
                unsetElementPicker(); // from `elementPicker.js`
                response({
                    event: REQUESTS.UNSET_ELEMENT_PICKER,
                    data: {
                        status: REQUESTS.SUCCESS
                    }
                });
            }
            break;

        case REQUESTS.UPDATE_PUZZLEME_IFRAME:
            sendToLogger('INFO', '[CONTENT-SCRIPT] {messageHandler.js}', 'Updating PuzzleMe iframe', { request: request });
            {
                const updateType = request.data.updateType;
                const updateData = request.data.updateData;

                updatePuzzleMeIframe(updateType, updateData);
                response({
                    event: REQUESTS.UPDATE_PUZZLEME_IFRAME,
                    data: {
                        status: REQUESTS.SUCCESS
                    }
                });
            }
            break;

        case REQUESTS.INJECT_PUZZLE:
            addPuzzleMeEventListeners(); // from `puzzleInjector.js`
            {

                const domainConfig = request.data.domainConfig;

                sendToLogger('INFO', '[CONTENT-SCRIPT] {messageHandler.js}', 'Injecting PuzzleMe', { domainConfig: domainConfig });

                let elementSelector = domainConfig.elementSelector;
                let selectedElement = getElementsBySelector(elementSelector)[0];

                injectPuzzle(domainConfig.url, domainConfig.height, domainConfig.width, selectedElement, domainConfig.replaceSwitch);
                smoothScrollToLatestPuzzleMeIframe();
                response({
                    event: REQUESTS.INJECT_PUZZLE,
                    data: {
                        status: REQUESTS.SUCCESS
                    }
                });
            }
            break;

        case REQUESTS.CHECK_NUMBER_OF_ELEMENTS:
            {

                const elementSelector = request.data.domainConfig.elementSelector;
                const elements = getElementsBySelector(elementSelector);

                sendToLogger('INFO', '[CONTENT-SCRIPT] {messageHandler.js}', 'Checking number of elements', { elementSelector: elementSelector });

                const numberOfElements = elements ? (elements[0] ? elements.length : 0) : 0;

                try {
                    document.getElementsByClassName(selectedClass)[0].classList.remove(selectedClass); 
                } catch {
                    sendToLogger('WARN', '[CONTENT-SCRIPT] {messageHandler.js}', 'No selected class found');
                }

                if (elements.length !== 0 && elements[0]) {
                    elements[0].classList.add(selectedClass);
                }

                response({
                    event: REQUESTS.CHECK_NUMBER_OF_ELEMENTS,
                    data: {
                        numberOfElements: numberOfElements
                    }
                });
            }
            break;

        default:
            sendToLogger('ERROR', '[CONTENT-SCRIPT] {messageHandler.js}', 'Unknown request', { request: request });
            response({
                event: REQUESTS.FAIL,
                data: {
                    status: REQUESTS.FAIL
                }
            });
            break;
    }
});
