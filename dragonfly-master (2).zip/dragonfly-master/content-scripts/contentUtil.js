// define eligible HTML tags and irreplaceable HTML tags
const eligibleHTMLTags = ["a",
    "acronym",
    "area",
    "article", ,
    "big",
    "blockquote",
    "body",
    "canvas",
    "center",
    "cite",
    "code",
    "col",
    "colgroup",
    "content",
    "data",
    "datalist",
    "dd",
    "del",
    "details",
    "dir",
    "div",
    "dl",
    "dt",
    "element",
    "em",
    "embed",
    "figure",
    "footer",
    "form",
    "frame",
    "frameset",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "head",
    "header",
    "iframe",
    "input",
    "legend",
    "main",
    "map",
    "menu",
    "nav",
    "object",
    "ol",
    "p",
    "param",
    "picture",
    "plaintext",
    "q",
    "samp",
    "section",
    "select",
    "source",
    "summary",
    "table",
    "tbody",
    "td",
    "template",
    "textarea",
    "tfoot",
    "th",
    "thead",
    "tr",
    "track",
    "xmp"
];
const irreplaceableHTMLTags = ["img", "video", "svg"];

// defining some requests, and responses
const REQUESTS = Object.freeze({
    CHECK_NUMBER_OF_ELEMENTS: 'checkNumberOfElements',
    SETUP_ELEMENT_PICKER: 'setupElementPicker',
    UNSET_ELEMENT_PICKER: 'unsetElementPicker',
    INJECT_PUZZLE: 'injectPuzzle',
    UPDATE_PUZZLEME_IFRAME: 'updatePuzzleMeIframe',
    UPDATE_PUZZLEME_THEME: 'updatePuzzleMeTheme',
    UPDATE_PUZZLEME_THEME_ONLOAD: 'updatePuzzleMeThemeOnload',
    UPDATE_DOMAIN_CONFIG: 'updateDomainConfig',
    VIEW_ON_MOBILE: 'viewOnMobile',
    SUCCESS: 'success',
    FAIL: 'fail',
    LOG: 'log'
});

// define some variables for shared usage
const eligibleTags = eligibleHTMLTags;
const identifierClass = 'df-identifier'; // can be changed/defined in `puzzle-me.css`
const selectedClass = 'df-selected'; // can be changed/defined in `puzzle-me.css`

/**
 * Sends a message to the background to log the message.
 * @param {string} level - log level
 * @param {string} location - script name
 * @param {any} message - message to log
 * @param {any} args - additional arguments to log
 */
function sendToLogger(level, location, message, ...args) {
    chrome.runtime.sendMessage({
        event: REQUESTS.LOG,
        data: {
            level: level,
            location: location,
            message: message,
            args: args
        }
    });
}

/**
 * Sends a message to the background to update the domain config.
 * @param {object} message - fields to update in the domain config
 */
function requestToUpdateDomainConfig(message) {
    chrome.runtime.sendMessage({
        event: REQUESTS.UPDATE_DOMAIN_CONFIG,
        data: {
            domainConfig: message
        }
    });
}

/**
 * Returns the element with the selector.
 * @param {string} selector - The selector to search for.
 * @returns {Array} an array of elements matching the selector.
 */
function getElementsBySelector(elementSelector) {

    if (elementSelector.startsWith('/')) {
        return [document.evaluate(elementSelector, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue]; // stackoverflow: https://stackoverflow.com/a/63106899
    } else {
        return document.querySelectorAll(elementSelector);
    }
}
